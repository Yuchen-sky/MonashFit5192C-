﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Calendar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DayRender(Object source, DayRenderEventArgs e)
    {
        if (e.Day.IsToday)
        {
            string connstr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|datadirectory|fit5192.accdb;Persist Security Info=False;";
            OleDbConnection conn = new OleDbConnection(connstr);
            String sql = "select * from [calendar] where EventDate = #" + e.Day.Date.ToString() + "#";
            OleDbCommand command = new OleDbCommand(sql, conn);
            OleDbDataReader dataReader = null;
            conn.Open();
            dataReader = command.ExecuteReader();
            List<List<String>> result = new List<List<String>>();
            while (dataReader.Read() == true)
            {
                List<String> resUnit = new List<string>();
                resUnit.Add(dataReader[0].ToString());
                resUnit.Add(dataReader[1].ToString());
                resUnit.Add(dataReader[2].ToString());
                result.Add(resUnit);
            }

            dataReader.Close();
            conn.Close();

            if (result.Count != 0)
            {
                e.Cell.BackColor = System.Drawing.Color.Yellow;
            }
            if (result.Count == 0)
            {
                event_time.Text = "No Event today";
                event_desp.Text = "No Event today";
            }
            for (int i = 0; i < result.Count; i++)
            {
                event_time.Text = result[i][1];
                event_desp.Text = result[i][2];
            }
        }
    }
}