﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Display : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }



    protected void GridView_OnRowCommand(object sender, GridViewCommandEventArgs e)
         {
            if (e.CommandName == "Operation")
            {
              int index = Convert.ToInt32(e.CommandArgument);
            String tem=gvCustomers.Rows[index].Cells[0].Text.ToString();

            //...
            String temp = "Displaydetail.aspx?field=" + tem;
            Response.Redirect(temp);

             }

        
         }

    protected void search(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");

    }

    protected override void Render(HtmlTextWriter writer)
    {
        TextWriter tw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(tw);
        base.Render(htw);
        string pageSource = tw.ToString();
        writer.Write(pageSource);
        Session["source_code_display"] = pageSource;
    }
    protected void Displayrecord(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(
        this.GetType(), "OpenWindow", "window.open('source_code_display.aspx','_newtab');", true);
    }

}