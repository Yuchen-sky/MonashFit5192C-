﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class Email : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }



    protected void GridView_OnRowCommand(object sender, GridViewCommandEventArgs e)
         {
            if (e.CommandName == "Operation")
            {
              int index = Convert.ToInt32(e.CommandArgument);
            String tem=gvCustomers.Rows[index].Cells[0].Text.ToString();

            //...
            String temp = "Displaydetail.aspx?field=" + tem;
            Response.Redirect(temp);

             }

        
         }

    protected void search(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");

    }

    protected override void Render(HtmlTextWriter writer)
    {
        TextWriter tw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(tw);
        base.Render(htw);
        string pageSource = tw.ToString();
        writer.Write(pageSource);
        Session["source_code_email"] = pageSource;
    }
    protected void emailrecord(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(
        this.GetType(), "OpenWindow", "window.open('source_code_email.aspx','_newtab');", true);
    }


    protected void send(object sender, EventArgs e)
    {
        int rowCount = gvCustomers.Rows.Count;
        int number = 0;
        string[] sendToEmail = new string[rowCount];
        string sendfrom = "";//this need to change.
        if (host.Text.Length > 12) sendfrom = host.Text;//this is helping to change testing
        string title = emailtitle.Text;
        string body = emailcontent.Text;
        string stmpcode = auth.Text;
        bool flag = false;
        string record="";
        string emailhost = "smtp.163.com";//this need to change if use other email server.

        for (int i = 0; i < rowCount; i++)
        {
            CheckBox tempChk = (CheckBox)gvCustomers.Rows[i].FindControl("Checkuser");

            if (tempChk.Checked == true)
            {
                sendToEmail[number++] = gvCustomers.Rows[i].Cells[0].Text.ToString();
                flag = true;
            }
        }
        if (flag)
        {
            for (int i = 0; i < number; i++)
            {
                try
                {
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host =emailhost;
                    smtp.Credentials = new NetworkCredential(sendfrom, stmpcode);
                    smtp.Send(sendfrom, sendToEmail[i],
                      title, body);
                    record += "<br/>The email has send to" + sendToEmail[i];



                }
                catch (Exception ex)
                {
                    if (i == 0) record += "<br/>facing problem: " + ex.Message;
                    else { record += "<br/>email " + sendToEmail[i] + "has problem: " + ex.Message; }
                }

            }


        }
        else { record += "you must choose at least one user."; }


        recordshow.Text = record;
    }

}