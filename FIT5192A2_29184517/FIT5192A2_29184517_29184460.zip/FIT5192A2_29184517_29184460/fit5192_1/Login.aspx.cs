﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void doingLogin(object sender, EventArgs e)
    {
        string strConnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|datadirectory|/fit5192.accdb;Persist Security Info=False;";
        string strSQL = "";
        string strResultsHolder = "";
       
        strSQL = "SELECT * FROM [user] WHERE [email] = '" + email.Text + "' AND [password] = '" + password.Text + "'";





        OleDbConnection objConnection = new OleDbConnection(strConnection);
        OleDbCommand objCommand = new OleDbCommand(strSQL, objConnection);
        OleDbDataReader objDataReader = null;
        objConnection.Open();
        objDataReader = objCommand.ExecuteReader();

        if (objDataReader.Read() == true)
        {
            //strResultsHolder += objDataReader[10].ToString();
            strResultsHolder += objDataReader[0].ToString();
            Session["hasLogin"] = strResultsHolder;
            Session["username"] = objDataReader[1].ToString()+" "+ objDataReader[2].ToString();
            FormsAuthentication.RedirectFromLoginPage(strResultsHolder, true);
            


        }
        objDataReader.Close();
        objConnection.Close();
        if (strResultsHolder == "")
        {
            Logininfo.Text = "<b style='color:red;'>Email or password is wrong.</b>";
        }
        

    }



    protected override void Render(HtmlTextWriter writer)
    {
        TextWriter tw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(tw);
        base.Render(htw);
        string pageSource = tw.ToString();
        writer.Write(pageSource);
        Session["source_code_login"] = pageSource;
    }
    protected void Loginrecord(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(
        this.GetType(), "OpenWindow", "window.open('source_code_login.aspx','_newtab');", true);
    }

}