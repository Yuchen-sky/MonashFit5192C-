﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{

    String First;
    String Last;
    int Age;
    int Postcode;
    String Phone;
    String Address;
    String Headimage;
    String Email;
    String Sexman;
    String Prefer;
    String Nationality;
    bool Isemployee;
    String Password;
    String Result;


    protected void Page_Load(object sender, EventArgs e)
    {

        Result = "";


        if (Page.IsPostBack)
        {

        }
    }


    protected void submit(object sender, EventArgs e)
    {
        Result += email.Text;
        Result += " ";
        result.Text = Result;

        First = first.Text;
        Last = last.Text;
        Age = Convert.ToInt32(age.Text);
        Postcode = Convert.ToInt32(postcode.Text);
        Password = password.Text;
        Email = email.Text;
        Headimage = head.Text;
        Phone = phone.Text;
        Address = address.Text;
        Prefer = "";
        Nationality = nation.SelectedItem.Value;
        Isemployee = employee.Checked;
        Sexman=sex.SelectedItem.Value;
            
        try
        {
            
            int listSelect = 0;
            
            if (prefer.Items[0].Selected)
            {
                Prefer +=  "milkTea ";
                listSelect += 1;
            }
            if (prefer.Items[1].Selected)
            {
                Prefer += "fruitTea ";
                listSelect += 1;
            }
            if (prefer.Items[2].Selected)
            {
                Prefer += "milkFoam ";
                listSelect += 1;
            }
            if (prefer.Items[3].Selected)
            {
                Prefer += "Tea ";
                listSelect += 1;
            }
            if (listSelect == 0)
            {
                
            }
        }
        catch
        {
            
        }

        saveData();

    }

    public static OleDbConnection getConn()
    {
        string connstr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|datadirectory|fit5192.accdb;Persist Security Info=False;";
        OleDbConnection tempconn = new OleDbConnection(connstr);
        return tempconn;
    }


    public  bool saveData()
    {


        bool tempvalue = false; //定义返回值，并设置初值
        //下面把note中的数据添加到数据库中！
        OleDbConnection conn = getConn(); //getConn():得到连接对象
        try
        {

            
            conn.Open();

            //设置SQL语句
            String sql = "INSERT INTO [user] ([firstname],[lastname],[age],[postcode],[phone],[address],[headimage],[email],[sex],[prefer],[nationality],[isemployee],[password])";
            sql += " VALUES(";
            sql += "'" + First + "',";
            sql += "'" + Last + "',";
            sql +=  age.Text + ",";
            sql += postcode.Text + ",";
            sql += "'" + Phone + "',";
            sql += "'" + Address + "',";
            sql += "'" + Headimage + "',";
            sql += "'" + Email + "',";
            sql += "'" + Sexman+ "',";
            sql += "'" + Prefer + "',";
            sql += "'" + Nationality + "',";
            sql +=  Isemployee + ",";
            sql += "'" + Password + "'";
            sql += ");";

            
            // string sqlText = String.Format("Insert into [user]([firstname],[lastname],[age],[postcode],[phone],[address],[headimage],[email],[sex],[prefer],[nationality],[isemployee],[password]) values ({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12})", First, Last, Age, Postcode, Phone, Address, Headimage, Email, Sexman, Prefer, Nationality, Isemployee, Password);
            OleDbCommand insertcmd = new OleDbCommand(sql, conn);
            insertcmd.ExecuteNonQuery();

            conn.Close();
            tempvalue = true;
        }
        catch (Exception e)
        {
            //throw (new Exception("数据库出错:" + e.Message));
            Result += "email has already exist." ;
            result.Text = Result;
        }
        finally {
            conn.Close();
        }
        if(tempvalue ==true) Response.Redirect("resuccess.aspx");

        return tempvalue;
    }


    protected override void Render(HtmlTextWriter writer)
    {
        TextWriter tw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(tw);
        base.Render(htw);
        string pageSource = tw.ToString();
        writer.Write(pageSource);
        Session["source_code_registration"] = pageSource;
    }
    protected void Addrecord(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(
        this.GetType(), "OpenWindow", "window.open('source_code_registration.aspx','_newtab');", true);
    }


}