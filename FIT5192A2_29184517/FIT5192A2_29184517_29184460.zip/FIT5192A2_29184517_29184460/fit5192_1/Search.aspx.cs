﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void RetrieveBook(object sender, EventArgs e)
    {
        string strConnection = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|datadirectory|/fit5192.accdb;Persist Security Info=False;";
        string strSQL = "";
        string strResultsHolder = "";
        if (IDcc.Text != "")
        {
            strSQL = "SELECT * FROM [user] WHERE ID LIKE '%" + IDcc.Text.Trim(' ') + "%'";
        }

        else if (Firstname.Text.Trim(' ') != "")
        {
            strSQL = "SELECT * FROM [user] WHERE firstname LIKE '%" + Firstname.Text.Trim(' ') + "%'";
        }
        else if (Address.Text.Trim(' ') != "")
        {
            strSQL = "SELECT * FROM [user] WHERE address LIKE '%" + Address.Text.Trim(' ') + "%'";
        }

        else
        {
            strSQL = "SELECT * FROM [user] ";
        }

        OleDbConnection objConnection = new OleDbConnection(strConnection);
        OleDbCommand objCommand = new OleDbCommand(strSQL, objConnection);
        OleDbDataReader objDataReader = null;
        objConnection.Open();
        objDataReader = objCommand.ExecuteReader();

        while (objDataReader.Read() == true)
        {
            //strResultsHolder += objDataReader[10].ToString();
            strResultsHolder += "<b>Id: " + objDataReader[0].ToString();
            strResultsHolder += "<br />First name: " + objDataReader[1].ToString();
            strResultsHolder += "&nbsp;&nbsp;&nbsp;Last name: " + objDataReader[2].ToString();
            strResultsHolder += "<br />Email: " + objDataReader[7].ToString()+"</b>";
            strResultsHolder += "<br />Age: " + objDataReader[3].ToString();
            strResultsHolder += "<br />Gender: " + objDataReader[8].ToString();
            strResultsHolder += "<br />Phone: " + objDataReader[13].ToString();
            strResultsHolder += "<br />Nationality: " + objDataReader[10].ToString();
            strResultsHolder += "&nbsp;&nbsp;&nbsp;Address: " + objDataReader[5].ToString();
            
            strResultsHolder += "<br /><hr /><br />";
        }
        objDataReader.Close();
        objConnection.Close();
        if (strResultsHolder == "")
        {
            strResultsHolder = "<b style='color:red;'>We do not have this user.</b>";
        }
        BookList.Text = strResultsHolder;
    }



    protected override void Render(HtmlTextWriter writer)
    {
        TextWriter tw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(tw);
        base.Render(htw);
        string pageSource = tw.ToString();
        writer.Write(pageSource);
        Session["source_code_search"] = pageSource;
    }
    protected void Searchrecord(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(
        this.GetType(), "OpenWindow", "window.open('source_code_searchrecord.aspx','_newtab');", true);
    }

}