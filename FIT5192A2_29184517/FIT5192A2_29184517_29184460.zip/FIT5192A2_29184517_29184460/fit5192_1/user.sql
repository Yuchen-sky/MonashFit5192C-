﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Firstname] VARCHAR(50) NULL, 
    [Lastname] VARCHAR(50) NULL, 
    [Age] INT NULL, 
    [Postcode] INT NULL
)
